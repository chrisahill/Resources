﻿using System;
using System.Threading.Tasks;
using System.Diagnostics;
using Windows.UI.Xaml;
using Microsoft.VisualStudio.TestPlatform.UnitTestFramework;
using System.Text;
using Windows.UI.Core;

namespace UnitTestSpike
{
    [TestClass]
    public class UnitTest1
    {
        long testNumber = 25000;

        [TestMethod]
        public async Task BeancCounter_CountTo()
        {
            await AsyncExtensions.ExecuteOnUIThread(() =>
            {
                BeanCounter beanCounter = new BeanCounter();
                beanCounter.CountTo(testNumber);
                Assert.IsFalse(beanCounter.IsCounting, "BeanCounter.IsCounting");
            });            
        }

        [TestMethod]
        public async Task BeanCounter_CountToAsync()
        {
            await AsyncExtensions.ExecuteOnUIThread(async () =>
            {
                BeanCounter beanCounter = new BeanCounter();
                await beanCounter.CountToAsync(testNumber);
                Assert.IsFalse(beanCounter.IsCounting, "BeanCounter.IsCounting");
            });     
        }                            
    }


    public class BeanCounter : DependencyObject
    {

        public bool IsCounting { get; set; }

        public void CountTo(long beans)        
        {
            IsCounting = true;
            StringBuilder sb = new StringBuilder();
            for (long i = 1; i <= beans; i++)
            {
                sb.Append(i);
                if(i < beans)
                    sb.Append( ",");
                if (i % 10 == 0)
                {
                    sb.AppendLine();
                    Debug.WriteLine(sb.ToString());
                    sb.Clear();
                }            
            }            
            sb = null;
            IsCounting = false;
        }

        public Task CountToAsync(long num)
        {
            return Task.Run(() => { CountTo(num); });
        }
    }


    public static class AsyncExtensions
    {
        /// <summary>
        /// Handles unit test that need to execute on UI thread Synchronously.
        /// </summary>
        /// <param name="unitTest">the unit test to execute</param>  
        public static Task ExecuteOnUIThread(Action unitTest)
        {
            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();
#if NETFX_CORE || WINDOWS_PHONE
            var dispatcher = Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher;
            var t = dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                try
                {
                    unitTest();
                    tcs.SetResult(true);
                }
                catch (Exception ex)
                {
                    tcs.SetException(ex);
                }
            });
#else
            DispatcherFrame frame = null;
            Action theAction = () =>
            {
                try
                {
                    unitTest();
                    tcs.SetResult(true);
                }
                catch (Exception ex)
                {
                    tcs.SetException(ex);
                }
            };
            Task.Factory.StartNew(() => { 
                frame = new DispatcherFrame();
                Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Normal, theAction);
                Dispatcher.PushFrame(frame);
            });
            
#endif
            return tcs.Task;
        }

        /// <summary>
        /// Handles unit test that need to execute on UI thread Asynchronously.
        /// </summary>
        /// <param name="unitTest">the unit test to execute</param>   
        public static Task ExecuteOnUIThread(Func<Task> unitTest)
        {
            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();
#if NETFX_CORE || WINDOWS_PHONE
            var dispatcher = Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher;
            var t = dispatcher.RunAsync(CoreDispatcherPriority.Normal, async () =>
            {
                try
                {
                    await unitTest();
                    tcs.SetResult(true);
                }
                catch (Exception ex)
                {
                    tcs.SetException(ex);
                }
            });
#else
            DispatcherFrame frame = null;
            Action theAction = async () =>
            {
                try
                {
                    await unitTest();
                    tcs.SetResult(true);
                }
                catch (Exception ex)
                {
                    tcs.SetException(ex);
                }
            };
            Task.Factory.StartNew(() => { 
                frame = new DispatcherFrame();
                Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Normal, theAction);
                Dispatcher.PushFrame(frame);
            });            
#endif
            return tcs.Task;
        }
    }
   
}
